(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var HTTP = Package.http.HTTP;
var HTTPInternals = Package.http.HTTPInternals;
var MongoInternals = Package.mongo.MongoInternals;
var Mongo = Package.mongo.Mongo;
var _ = Package.underscore._;

/* Package-scope variables */
var Twilio;

(function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                      //
// packages/dispatch_twilio/packages/dispatch_twilio.js                                                 //
//                                                                                                      //
//////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                        //
(function () {

///////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                               //
// packages/dispatch:twilio/twilio.js                                                            //
//                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                 //
var twilio = Npm.require('twilio');                                                              // 1
                                                                                                 // 2
var lookups = new Mongo.Collection('twilio.lookups');                                            // 3
                                                                                                 // 4
Twilio = function (options) {                                                                    // 5
  var self = this;                                                                               // 6
                                                                                                 // 7
  options = _.extend({                                                                           // 8
    // default                                                                                   // 9
  }, options);                                                                                   // 10
                                                                                                 // 11
  check(options, {                                                                               // 12
    from: String,                                                                                // 13
    sid: String,                                                                                 // 14
    token: String                                                                                // 15
  });                                                                                            // 16
                                                                                                 // 17
  self.client = new twilio(options.sid, options.token);                                          // 18
  self.from = options.from;                                                                      // 19
  self.auth = options.sid + ':' + options.token;                                                 // 20
};                                                                                               // 21
                                                                                                 // 22
/*                                                                                               // 23
 * Send an sms to a phone number with a message.                                                 // 24
 * @param options                                                                                // 25
 * {String} options.to                                                                           // 26
 * {String} options.body                                                                         // 27
 * {String} [options.from] Specify a different number to send the sms from.                      // 28
 * @param {Function} [callback]                                                                  // 29
 */                                                                                              // 30
Twilio.prototype.sendSMS = function (options, callback) {                                        // 31
  var self = this;                                                                               // 32
                                                                                                 // 33
  options = _.extend({                                                                           // 34
    from: self.from                                                                              // 35
  }, options);                                                                                   // 36
                                                                                                 // 37
  check(options, {                                                                               // 38
    to: String,                                                                                  // 39
    from: String,                                                                                // 40
    body: String,                                                                                // 41
    statusCallback: Match.Optional(String)                                                       // 42
  });                                                                                            // 43
                                                                                                 // 44
  return Meteor.wrapAsync(self.client.sendMessage).call(self.client, options, callback);         // 45
};                                                                                               // 46
                                                                                                 // 47
/*                                                                                               // 48
 * Send an mms to a phone number with a message and media.                                       // 49
 * @param options                                                                                // 50
 * {String} options.to                                                                           // 51
 * {String} options.body                                                                         // 52
 * {String} options.mediaUrl                                                                     // 53
 * {String} [options.from] Specify a different number to send the sms from.                      // 54
 * {String} [options.statusCallback] Specify a callback URL for Twilio to hit for status updates // 55
 * @param {Function} [callback]                                                                  // 56
 */                                                                                              // 57
Twilio.prototype.sendMMS = function (options, callback) {                                        // 58
  var self = this;                                                                               // 59
                                                                                                 // 60
  options = _.extend({                                                                           // 61
    from: self.from                                                                              // 62
  }, options);                                                                                   // 63
                                                                                                 // 64
  check(options, {                                                                               // 65
    to: String,                                                                                  // 66
    from: String,                                                                                // 67
    body: String,                                                                                // 68
    mediaUrl: Match.Optional(String),                                                            // 69
    statusCallback: Match.Optional(String)                                                       // 70
  });                                                                                            // 71
                                                                                                 // 72
  return Meteor.wrapAsync(self.client.messages.post).call(self.client, options, callback);       // 73
};                                                                                               // 74
                                                                                                 // 75
/*                                                                                               // 76
 * Call a phone number.                                                                          // 77
 * @param options                                                                                // 78
 * {String} options.to                                                                           // 79
 * {String} [options.from] Specify a different number to call from.                              // 80
 * {String} [options.statusCallback] Specify a callback URL for Twilio to hit for status updates // 81
 * @param {Function} [callback]                                                                  // 82
 */                                                                                              // 83
Twilio.prototype.makeCall = function (options, callback) {                                       // 84
  var self = this;                                                                               // 85
                                                                                                 // 86
  options = _.extend({                                                                           // 87
    from: self.from                                                                              // 88
  }, options);                                                                                   // 89
                                                                                                 // 90
  check(options, {                                                                               // 91
    to: String,                                                                                  // 92
    from: String,                                                                                // 93
    statusCallback: Match.Optional(String)                                                       // 94
  });                                                                                            // 95
                                                                                                 // 96
  return Meteor.wrapAsync(self.client.makeCall).call(self.client, options, callback);            // 97
};                                                                                               // 98
                                                                                                 // 99
/*                                                                                               // 100
 * Asynchronously look up information about a phone number.                                      // 101
 * @param {String} phoneNumber                                                                   // 102
 * @param options                                                                                // 103
 * {String} [options.Type] Get more information about the number. Ex. Type: 'carrier'            // 104
 * {String} [options.country_code]                                                               // 105
 * {String} [options.statusCallback] Specify a callback URL for Twilio to hit for status updates // 106
 * @param {Function} [callback]                                                                  // 107
 */                                                                                              // 108
Twilio.prototype.lookupAsync = function (phoneNumber, options, callback) {                       // 109
  var self = this;                                                                               // 110
                                                                                                 // 111
  check(phoneNumber, String);                                                                    // 112
                                                                                                 // 113
  if (_.isFunction(options)) {                                                                   // 114
    callback = options;                                                                          // 115
    options = {};                                                                                // 116
  }                                                                                              // 117
                                                                                                 // 118
  var info = lookups.findOne({                                                                   // 119
    phoneNumber: phoneNumber                                                                     // 120
  });                                                                                            // 121
                                                                                                 // 122
  if (info) {                                                                                    // 123
    callback(null, info);                                                                        // 124
  } else {                                                                                       // 125
                                                                                                 // 126
    HTTP.get('https://lookups.twilio.com/v1/PhoneNumbers/' + phoneNumber, {                      // 127
      auth: self.auth,                                                                           // 128
      params: options                                                                            // 129
    }, function (error, response) {                                                              // 130
      if (error) {                                                                               // 131
        callback(error);                                                                         // 132
      } else {                                                                                   // 133
        lookups.insert(response.data);                                                           // 134
        callback(null, response.data);                                                           // 135
      }                                                                                          // 136
    });                                                                                          // 137
                                                                                                 // 138
  }                                                                                              // 139
};                                                                                               // 140
                                                                                                 // 141
/*                                                                                               // 142
 * Synchronously look up information about a phone number.                                       // 143
 * @param {String} phoneNumber                                                                   // 144
 * @param options                                                                                // 145
 * {String} [options.Type] Get more information about the number. Ex. Type: 'carrier'            // 146
 * {String} [options.country_code]                                                               // 147
 * @param {Function} [callback]                                                                  // 148
 */                                                                                              // 149
Twilio.prototype.lookup = function (phoneNumber, options, callback) {                            // 150
  var self = this;                                                                               // 151
                                                                                                 // 152
  return Meteor.wrapAsync(self.lookupAsync).call(self, phoneNumber, options, callback);          // 153
};                                                                                               // 154
                                                                                                 // 155
///////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

//////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['dispatch:twilio'] = {}, {
  Twilio: Twilio
});

})();
