var require = meteorInstall({"imports":{"api":{"numbers.js":["meteor/mongo",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// imports/api/numbers.js                                                                                        //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.export({Numbers:function(){return Numbers},Groups:function(){return Groups},Responses:function(){return Responses}});var Mongo;module.import('meteor/mongo',{"Mongo":function(v){Mongo=v}});
                                                                                                                 //
var Numbers = new Mongo.Collection('numbers');                                                                   // 3
var Groups = new Mongo.Collection('groups');                                                                     // 4
var Responses = new Mongo.Collection('responses');                                                               // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"server":{"main.js":["../imports/api/numbers.js","twilio","node-cron",function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
module.import('../imports/api/numbers.js');var twilio;module.import('twilio',{"default":function(v){twilio=v}});var Responses;module.import('../imports/api/numbers.js',{"Responses":function(v){Responses=v}});
//const twilio = Meteor.npmRequire('twilio')                                                                     // 2
                                                                                                                 // 3
                                                                                                                 // 4
var cron = require('node-cron');                                                                                 // 5
                                                                                                                 //
Meteor.startup(function () {                                                                                     // 7
  // code to run on server at startup                                                                            // 8
  //Meteor.absoluteUrl.defaultOptions.rootUrl = 'http://xxx.ngrok.io';                                           // 9
                                                                                                                 //
                                                                                                                 //
  Router.route('/twilio/handle', {                                                                               // 12
    where: 'server'                                                                                              // 13
  }).get(function () {                                                                                           // 12
    console.log(this.params.query.From);                                                                         // 16
    console.log(this.params.query.Body);                                                                         // 17
    //var reply = '<?xml version="1.0" encoding="UTF-8"?><Response><Sms from="[TWILIOFROM]" to="[TO]">[BODY]</Sms></Response>'
    // .replace('[TWILIOFROM]', this.params.query.To)                                                            // 19
    // .replace('[TO]', this.params.query.From)                                                                  // 20
    // .replace('[BODY]', 'fuckoff');                                                                            // 21
    //this.response.end(reply);                                                                                  // 22
    Responses.insert({ user: this.params.query.From, response: this.params.query.Body, createdAt: new Date() });
    if (this.params.query.Body == 'Join') {                                                                      // 24
      console.log('someone joined');                                                                             // 26
    }                                                                                                            // 27
    Meteor.call('sendSMS', this.params.query.From, 'Welcome', function (err, response) {                         // 28
      if (err) {                                                                                                 // 29
        return;                                                                                                  // 30
      }                                                                                                          // 31
      console.log(response);                                                                                     // 32
    });                                                                                                          // 33
  });                                                                                                            // 34
                                                                                                                 //
  cron.schedule('9 19 * * *', function () {                                                                      // 36
    console.log('running cron');                                                                                 // 37
    console.log(new Date());                                                                                     // 38
  });                                                                                                            // 41
                                                                                                                 //
  Meteor.methods({                                                                                               // 44
    sendSMS: function () {                                                                                       // 45
      function sendSMS(number, message) {                                                                        // 45
        var accountSid = 'AC0ebf069ec19135f7be54fa875f69e023';                                                   // 46
        var authToken = "02e71257ffb78241ac845d04ab5e3aaa";                                                      // 47
        var client = require('twilio')(accountSid, authToken);                                                   // 48
        console.log(message);                                                                                    // 49
        client.sendMessage({                                                                                     // 50
          to: number, // Any number Twilio can deliver to                                                        // 51
          from: "+14013541756", // A number you bought from Twilio and can use for outbound communication        // 52
          body: message // body of the SMS message                                                               // 53
                                                                                                                 //
        }, function (err, responseData) {                                                                        // 50
          //this function is executed when a response is received from Twilio                                    // 55
                                                                                                                 //
          console.log(err);                                                                                      // 57
          if (!err) {                                                                                            // 58
            // "err" is an error received during the request, if any                                             // 58
                                                                                                                 //
            // "responseData" is a JavaScript object containing data received from Twilio.                       // 60
            // A sample response from sending an SMS message is here (click "JSON" to see how the data appears in JavaScript):
            // http://www.twilio.com/docs/api/rest/sending-sms#example-1                                         // 62
                                                                                                                 //
            console.log(responseData.from); // outputs "+14506667788"                                            // 64
            console.log(responseData.body); // outputs "word to your mother."                                    // 65
          }                                                                                                      // 67
        });                                                                                                      // 68
        return 'sent';                                                                                           // 69
      }                                                                                                          // 70
                                                                                                                 //
      return sendSMS;                                                                                            // 45
    }()                                                                                                          // 45
  });                                                                                                            // 44
});                                                                                                              // 77
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json",".html"]});
require("./server/main.js");
//# sourceMappingURL=app.js.map
